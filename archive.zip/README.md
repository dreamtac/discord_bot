# Discord.js v14 Starter Files

Command + event handler included
